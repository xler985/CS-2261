#include "myLib.h"

// Prototypes
void initialize();
void update();
void draw();

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

// Background Variables
unsigned short bgColor;

// Green Rectangle Variables
int gCol;
int gRow;
int gOldCol;
int gOldRow;
int gCDel;
int gRDel;
int gWidth;
int gHeight;

// Blue Rectangle Variables
int bCol;
int bRow;
int bOldCol;
int bOldRow;
int bCDel;
int bRDel;
int bWidth;
int bHeight;

int main() {

	initialize();

	while(1) {

		// TODO #3.6: Update the button variables each frame



		update();
		waitForVBlank();
		draw();
	}
}

// Sets up the display and the game objects
void initialize() {

	REG_DISPCTL = MODE3 | BG2_ENABLE;

	// TODO #3.3: Intialize your button variables




	// Initialize background
	// UNCOMMENT #2
	// bgColor = CYAN;
	// fillScreen(bgColor);

	// Initialize green rectangle
	gCol = 20;
	gRow = 20;
	gOldCol = gCol;
	gOldRow = gRow;
	gCDel = 1;
	gRDel = 1;
	gWidth = 15;
	gHeight = 19;

	// Initialize blue rectangle
	bCol = 120;
	bRow = 120;
	bOldCol = bCol;
	bOldRow = bRow;
	bCDel = 1;
	bRDel = 1;
	bWidth = 10;
	bHeight = 17;
}

// Performs all of the game's calculations
void update() {

	// Change the background color if Start is pressed
	// UNCOMMENT #3
	// if (BUTTON_PRESSED(BUTTON_START)) {
	// 	if (bgColor == CYAN)
	// 		bgColor = YELLOW;
	// 	else
	// 		bgColor = CYAN;
	// 	fillScreen(bgColor);
	// }

	// Move the blue rectangle with the buttons
	// TODO #4: Make the blue rectangle move with the arrow keys











	// Bounce green rectangle off the walls
	if (gCol <= 0 || gCol + gWidth - 1 >= SCREENWIDTH - 1)
		gCDel *= -1;
	if (gRow <= 0 || gRow + gHeight - 1 >= SCREENHEIGHT - 1)
		gRDel *= -1;

	// Bounce green rectangle off the blue rectangle
	// TODO #5.5: Make the green rectangle reverse direction when it hits the blue one





	// Update green rectangle's position
	gCol += gCDel;
	gRow += gRDel;
}

// Performs all of the writing to the screen
void draw() {

	// UNCOMMENT #1
	// // Erase the previous locations
	// drawRect(gOldCol, gOldRow, gWidth, gHeight, bgColor);
	// drawRect(bOldCol, bOldRow, bWidth, bHeight, bgColor);

	// // Draw the new locations
	// drawRect(gCol, gRow, gWidth, gHeight, GREEN);
	// drawRect(bCol, bRow, bWidth, bHeight, BLUE);

	// Update old variables
	gOldCol = gCol;
	gOldRow = gRow;
	bOldCol = bCol;
	bOldRow = bRow;
}