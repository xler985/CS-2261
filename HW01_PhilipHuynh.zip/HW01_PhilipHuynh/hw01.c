// GBA Video Registers and Flags
#define REG_DISPCTL (*(unsigned short *)0x4000000)
#define MODE3 3
#define BG2_ENABLE (1<<10)
#define VIDEO_BUFFER ((u16*)0x06000000)

// Create a color with the specified RGB values
#define COLOR(r, g, b) ((r) | (g)<<5 | (b)<<10)

// Calculate the position of a pixel based on its row and column
#define OFFSET(r, c, rowlen) ((r)*(rowlen)+(c))
#define setPixel(x, y, val) (VIDEO_BUFFER[(x) + (y)*240] = val)

// Predefined colors
#define RED COLOR(31, 0, 0)
#define GREEN COLOR(0, 31, 0)
#define BLUE COLOR(0, 0, 31)
#define MAGENTA COLOR(31, 0, 31)
#define CYAN COLOR(0, 31, 31)
#define YELLOW COLOR(31, 31, 0)
#define BLACK 0
#define WHITE COLOR(31, 31, 31)
//default pixel 0 location; set pixcel commad 
#define PIXEL_00 0x06000000 


// Function Prototypes
void drawTriangle(int, int);
void animateFrame(int, int, int, short);
void animateRight(int, int, int, int, short);
void animateLeft(int, int, int, int, short);
void animateUp(int, int, int, int, short);
void animateDown(int, int, int, int, short);


// Global Variables
unsigned short *videoBuffer = (unsigned short *)0x6000000;
typedef unsigned short u16;

int main() {

    REG_DISPCTL = MODE3 | BG2_ENABLE;
    while (1) {
        animateRight(10, 10, 100, 5, RED);
        animateDown(110, 10, 100, 5, CYAN);
        animateLeft(110, 110, 100, 5, GREEN);
        animateUp(10, 110, 100, 5, WHITE);
    }
}

void animateFrame(int col, int row, int amount, short color) {
    for (int i = 1;  i < 25; i++){
        for (int j = i; j < 25; j++){
            setPixel((col + j), (row + i), color);
        }
    }
    volatile int trash = 0;
    for(int i = 0; i < amount*1000; i++) {
        trash++;
    }
    for (int i = 1;  i < 25; i++){
        for (int j = i; j < 25; j++){
            setPixel((col + j), (row + i), BLACK);
        }
    }
}

void animateRight(int col, int row, int delay, int length, short color) {
    for (int i = 0;  i < length; i++){
        animateFrame((col + (i*20)), row, delay, color);
    }
}
void animateLeft(int col, int row, int delay, int length, short color) {
    for (int i = 0;  i < length; i++){
        animateFrame((col - (i*20)), row, delay, color);
    }
}
void animateUp(int col, int row, int delay, int length, short color) {
    for (int i = 0;  i < length; i++){
        animateFrame(col, (row - (i*20)), delay, color);
    }
}
void animateDown(int col, int row, int delay, int length, short color) {
    for (int i = 0;  i < length; i++){
        animateFrame(col, (row + (i*20)), delay, color);
    }
}
