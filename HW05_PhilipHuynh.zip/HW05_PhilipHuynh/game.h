OBJ_ATTR shadowOAM[128];

//Ship Struct
typedef struct {
	int row;
	int col;
	int cdel;
	int rdel;
	int height;
	int width;
	int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
	int bulletTimer;
} SHIP;


// Bullet Struct
typedef struct {
	int row;
	int col;
	int rdel;
	int height;
	int width;
	int active;
	int id;
} BULLET;


// alien Struct
typedef struct {
	int row;
	int col;
	int oldRow;
	int oldCol;
	int rdel;
	int cdel;
	int height;
	int width;
	unsigned short color;
	int active;
	int erased;
	int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
	int alienType;
	int id;
	int bulletTimer;
} ALIEN;

// Alien Bullet Struct
typedef struct {
	int row;
	int col;
	int rdel;
	int height;
	int width;
	int active;
	int id;
} BULLETEVIL;



// Constants
#define BULLETCOUNT 5
#define ALIENCOUNT 25

// Variables
extern SHIP ship;
extern BULLET bullets[BULLETCOUNT];
extern BULLETEVIL bulletsEvil[BULLETCOUNT];
extern ALIEN aliens[ALIENCOUNT];
extern int aliensRemaining;
extern int livesRemaining;

// Prototypes
void initGame();
void updateGame();
void drawGame();
void drawBar();

void initShip();
void updateShip();
void drawShip();

void initBullets();
void fireBullet();
void updateBullet(BULLET *);
void drawBullet(BULLET *);
void initaliens();
void updateAlien(ALIEN *);
void drawAlien(ALIEN *);
void initBulletsEvil();
void fireBulletEvil(ALIEN *);
void updateBulletEvil(BULLETEVIL *);
void drawBulletEvil(BULLETEVIL *);
