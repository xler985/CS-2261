
//{{BLOCK(loseScreen)

//======================================================================
//
//	loseScreen, 256x256@4, 
//	+ 91 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 2912 + 2048 = 4960
//
//	Time-stamp: 2019-10-25, 21:05:53
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LOSESCREEN_H
#define GRIT_LOSESCREEN_H

#define loseScreenTilesLen 2912
extern const unsigned short loseScreenTiles[1456];

#define loseScreenMapLen 2048
extern const unsigned short loseScreenMap[1024];

#endif // GRIT_LOSESCREEN_H

//}}BLOCK(loseScreen)
