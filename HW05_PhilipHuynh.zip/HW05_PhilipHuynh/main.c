#include <stdio.h>
#include <stdlib.h>
#include "myLib.h"
#include "background.h"
#include "startscreen.h"
#include "pauseScreen.h"
#include "winScreen.h"
#include "loseScreen.h"
#include "spritesheet.h"
#include "game.h"


// Prototypes
void initialize();
void goToStart();
void start();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();
void goToLose();
void lose();

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

// Horizontal Offset
unsigned short hOff;

// Shadow OAM
OBJ_ATTR shadowOAM[128];

//enums
enum {START, GAME, PAUSE, WIN, LOSE};
int state;
int seed;

int main() {

    initialize();

    while(1) {
        oldButtons = buttons;
        buttons = BUTTONS;

         switch(state) {
            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case PAUSE:
                pause();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
        }
	}
}

// Initialize the game on first launch
void initialize() {

    // TODO 2.1 - set up display control register
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;

    // TODO 2.2 - load tile palette
    DMANow(3, backgroundPal, PALETTE, 256);

    // TODO 4.2 - set up bg 0 control register
    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(31) | BG_SIZE_SMALL;
    REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(30) | BG_SIZE_SMALL;

    DMANow(3, backgroundTiles, &CHARBLOCK[0], backgroundTilesLen / 2);
    DMANow(3, backgroundMap, &SCREENBLOCK[31], backgroundMapLen / 2);

    DMANow(3, startscreenTiles, &CHARBLOCK[1], startscreenTilesLen / 2);
    DMANow(3, startscreenMap, &SCREENBLOCK[30], startscreenMapLen / 2);

    DMANow(3, spritesheetPal, SPRITEPALETTE, 256);
	DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);

    hOff = 0;
    buttons = BUTTONS;
}

// Sets up the start state
void goToStart() {
    hideSprites();
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
    REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(30) | BG_SIZE_SMALL;
    DMANow(3, startscreenTiles, &CHARBLOCK[1], startscreenTilesLen / 2);
    DMANow(3, startscreenMap, &SCREENBLOCK[30], startscreenMapLen / 2);
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, (128 * 4));
    state = START;
    seed = 0;
}

// Runs every frame of the start state
void start() {
    hideSprites();
    seed++;
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, (128 * 4));
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)) {
        // Seed the random generator
        srand(seed);
        initGame();
        goToGame();
        
    }
}

// Sets up the game state
void goToGame() {
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, (128 * 4));
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    state = GAME;
}

// Runs every frame of the game state
void game() {
    updateGame();
    drawGame();
    REG_BG0HOFF = hOff;
    if (BUTTON_PRESSED(BUTTON_START))
        goToPause();
    if (livesRemaining <= 0) 
        goToLose();
    if (aliensRemaining <= 0) 
        goToWin();
}

// Sets up the pause state
void goToPause() {
    hideSprites();
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
    REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(30) | BG_SIZE_SMALL;
    DMANow(3, pauseScreenTiles, &CHARBLOCK[1], pauseScreenTilesLen / 2);
    DMANow(3, pauseScreenMap, &SCREENBLOCK[30], pauseScreenMapLen / 2);
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, (128 * 4));
    state = PAUSE;
}

// Runs every frame of the pause state
void pause() {
    waitForVBlank();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToGame();
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();
}

// Sets up the win state
void goToWin() {
    hideSprites();
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
    REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(30) | BG_SIZE_SMALL;
    DMANow(3, winScreenTiles, &CHARBLOCK[1], winScreenTilesLen / 2);
    DMANow(3, winScreenMap, &SCREENBLOCK[30], winScreenMapLen / 2);
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, (128 * 4));
    state = WIN;
}

// Runs every frame of the win state
void win() {
    // Lock the framerate to 60 fps
    waitForVBlank();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}

// Sets up the lose state
void goToLose() {
    hideSprites();
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
    REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(30) | BG_SIZE_SMALL;
    DMANow(3, loseScreenTiles, &CHARBLOCK[1], loseScreenTilesLen / 2);
    DMANow(3, loseScreenMap, &SCREENBLOCK[30], loseScreenMapLen / 2);
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, (128 * 4));
    state = LOSE;
}

// Runs every frame of the lose state
void lose() {
    // Lock the framerate to 60 fps
    waitForVBlank();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart(); 
}

