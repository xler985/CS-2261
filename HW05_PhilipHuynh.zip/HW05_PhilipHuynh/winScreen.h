
//{{BLOCK(winScreen)

//======================================================================
//
//	winScreen, 256x256@4, 
//	+ 105 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 3360 + 2048 = 5408
//
//	Time-stamp: 2019-10-25, 21:08:22
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_WINSCREEN_H
#define GRIT_WINSCREEN_H

#define winScreenTilesLen 3360
extern const unsigned short winScreenTiles[1680];

#define winScreenMapLen 2048
extern const unsigned short winScreenMap[1024];

#endif // GRIT_WINSCREEN_H

//}}BLOCK(winScreen)
