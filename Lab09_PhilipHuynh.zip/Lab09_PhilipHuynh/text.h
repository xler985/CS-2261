/*********************************************************************
 *
 * text.h
 *
 ********************************************************************/
#ifndef TEXT_H
#define TEXT_H

// Mode 3 Text-drawing prototypes
void drawChar3(int col, int row, char ch, unsigned short color);
void drawString3(int col, int row, char *str, unsigned short color);

// Mode 4 Text-drawing prototypes
void drawChar4(int col, int row, char ch, unsigned char colorIndex);
void drawString4(int col, int row, char *str, unsigned char colorIndex);

extern const unsigned char fontdata_6x8[12288];

#endif
