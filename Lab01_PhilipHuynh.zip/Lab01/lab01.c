// GBA Video Registers and Flags
#define REG_DISPCTL (*(unsigned short *)0x4000000)
#define MODE3 3
#define BG2_ENABLE (1<<10)

// Create a color with the specified RGB values
#define COLOR(r, g, b) ((r) | (g)<<5 | (b)<<10)

// Calculate the position of a pixel based on its row and column
#define OFFSET(r, c, rowlen) ((r)*(rowlen)+(c))

// Predefined colors
#define RED COLOR(31, 0, 0)
#define GREEN COLOR(0, 31, 0)
#define BLUE COLOR(0, 0, 31)
#define MAGENTA COLOR(31, 0, 31)
#define CYAN COLOR(0, 31, 31)
#define YELLOW COLOR(31, 31, 0)
#define BLACK 0
#define WHITE COLOR(31, 31, 31)
//default pixel 0 location; set pixcel commad
#define PIXEL_00 0x06000000 


// Function Prototypes
void setPixel(int, int, unsigned short);
void drawTriangle(int, int);

// Global Variables
unsigned short *videoBuffer = (unsigned short *)0x6000000;
typedef unsigned short u16;

int main() {

    REG_DISPCTL = MODE3 | BG2_ENABLE;

    // TODO: Call your drawTriangle function three times
    drawTriangle(30,4);
    drawTriangle(7,100);
    drawTriangle(200,15);
    
    while(1);
}

void setPixel(int col, int row, unsigned short color) {
     (*(u16*)(PIXEL_00 + 2*((col) + 240*(row))) = color);
}

void drawTriangle(int col, int row) {

    for (int i = 1;  i < 25; i++){
        for (int j = i; j < 25; j++){
            setPixel((col + j), (row + i), RED);
        }
    }
}
