// Player Struct
typedef struct paddle {
	int row;
	int col;
	int cdel;
	int height;
	int width;
	unsigned char color;
} PADDLE;

// Bullet Struct
typedef struct ball {
	int row;
	int col;
	int rdel;
	int cdel;
	int height;
	int width;
	unsigned char color;
} BALL;

// Ball Struct
typedef struct fruit {
	int row;
	int col;
	int height;
	int width;
	int cdel;
	int fruitType;
	int active;
} FRUIT;

//Constant 
#define COUNT 15


// Variables
extern PADDLE paddle;
extern BALL ball;
extern FRUIT fruits[COUNT];
extern int fruitsRemaining;

// Custom Game Colors
#define NUMCOLORS 6
// This does an enum trick to make them the last indeces of the palette
enum {BLACKID=(256-NUMCOLORS), BLUEID, GREENID, REDID, WHITEID, GRAYID};
extern unsigned short colors[NUMCOLORS];

// Prototypes
void initGame();
void updateGame();
void drawGame();
void drawBar();
void initPaddle();
void updatePaddle();
void drawPaddle();
void initBall();
void updateBall(BALL *);
void drawBall(BALL *);
void initFruits();
void updateFruits(FRUIT *);
void drawFruits(FRUIT *);