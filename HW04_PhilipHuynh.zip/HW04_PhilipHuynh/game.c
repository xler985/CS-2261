#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "apple.h"
#include "kiwi.h"
#include "orange.h"

//Variables
PADDLE paddle;
FRUIT fruits[COUNT];
BALL ball;
int fruitsRemaining;

// Initialize the game
void initGame() {

	initPaddle();
    initBall();
    initFruits();
	
    // Initialize the score
	fruitsRemaining = COUNT;

    // Initialize the colors
    unsigned short colors[NUMCOLORS] = {BLACK, BLUE, GREEN, RED, WHITE, GRAY};

	DMANow(3, &applePal, PALETTE, applePalLen);

    // Load the custom game colors to the end
    for (int i = 0; i < NUMCOLORS; i++) {
        PALETTE[256-NUMCOLORS+i] = colors[i];
    }
}

// Updates the game each frame
void updateGame() {

	updatePaddle();
	updateBall(&ball);
	// Update all the balls
	for (int i = 0; i < COUNT; i++)
		updateFruits(&(fruits[i]));
}

// Draws the game each frame
void drawGame() {

    fillScreen4(BLACKID);
	drawBar();
	drawPaddle();
	drawBall(&ball);
	// Draw all the fruits
	for (int i = 0; i < COUNT; i++)
		drawFruits(&fruits[i]);
}

// Draws the bar behind the paddle
void drawBar() {
	drawRect4(0, 140, 240, 3, REDID);
}

// Initialize the paddle
void initPaddle() {
	paddle.col = 120;
	paddle.row = 130;
	paddle.cdel = 5;
	paddle.height = 5;
	paddle.width = 45;
	paddle.color = GREENID;
}

// Handle every-frame actions of the paddle
void updatePaddle() {

	// Move the paddle
	if (BUTTON_HELD(BUTTON_LEFT)
		&& paddle.col >= paddle.cdel) {

		paddle.col -= paddle.cdel;

	} else if (BUTTON_HELD(BUTTON_RIGHT)
		&& paddle.col + paddle.width - 1 < SCREENWIDTH - paddle.cdel) {

		paddle.col += paddle.cdel;

	}
	if (collision(paddle.col, paddle.row, paddle.width /3, paddle.height, ball.col, ball.row, ball.width, ball.height)) {
		ball.rdel *= -1;
		if (ball.cdel >= 0) {
			ball.cdel *= -1;
		}
	}
	if (collision(paddle.col + 15, paddle.row, paddle.width /3, paddle.height, ball.col, ball.row, ball.width, ball.height)) {
		ball.rdel *= -1;
	}
	if (collision(paddle.col + 30, paddle.row, paddle.width /3, paddle.height, ball.col, ball.row, ball.width, ball.height)) {
		ball.rdel *= -1;
		if (ball.cdel <= 0) {
			ball.cdel *= -1;
		}
	}
}

// Draw the paddle
void drawPaddle() {
	drawRect4(paddle.col, paddle.row, paddle.width, paddle.height, paddle.color);
}

void initBall() {
	ball.col = paddle.col;
	ball.row = paddle.row - 10;
	ball.height = 5; 
	ball.width = 5;    
	ball.rdel = -1;
    ball.cdel = 1;
	ball.color = WHITEID;
}

void drawBall(BALL* b) {
	drawRect4(b->col, b->row, b->width, b->height, b->color);
}

// Handle every-frame actions of a bullet
void updateBall(BALL* b) {
	// Bounce the ball off the sides of the box
	if (b->row <= 1 || b->row + b->height-1 >= 137)
		b->rdel *= -1;
	if (b->col <= 1 || b->col + b->width-1 >= SCREENWIDTH-2)
		b->cdel *= -1;
	// Move the ball
	b->row += b->rdel;
	b->col += b->cdel;
}

// Initialize the fruits
void initFruits() {
	for (int i = 0; i < COUNT; i++) {
		fruits[i].height = 20;
		fruits[i].width = 20;
		fruits[i].col = (i*48) % 240 + 15;
		if ((i%3) == 0) {
			fruits[i].row = 0;
		} else if ((i%3) == 1) {
			fruits[i].row = 30;
		} else {
			fruits[i].row = 60;
		}
		fruits[i].fruitType = rand() % 3;
		fruits[i].active = 1;
		fruits[i].cdel = 1;
	}
}

// Handle every-frame actions of a ball
void updateFruits(FRUIT* b) {
	if (b->active) {
		// Handle ball-bullet collisions
		if (b->active == 1 && (collision(b->col, b->row, b->width, 1,
			ball.col, ball.row, ball.width, ball.height) || collision(b->col, b->row + b->height, b->width, 1,
			ball.col, ball.row, ball.width, ball.height))) { //Horizontal Sides of Fruits
			// Put ball back in the pool
			b->active = 0;
			ball.rdel *= -1;
			// Update the score
			fruitsRemaining--;
		}
		if (b->active == 1 && (collision(b->col, b->row, 1, b->height,
			ball.col, ball.row, ball.width, ball.height) || collision(b->col + b->width, b->row, 1, b->height,
			ball.col, ball.row, ball.width, ball.height))) { //Horizontal Sides of Fruits
			// Put ball back in the pool
			b->active = 0;
			ball.cdel *= -1;
			// Update the score
			fruitsRemaining--;
		}
		b->col += b->cdel;

		if (b->col >= 240) {
			b->col = 0;
			b->row += 1;
		}
		if (b->col < 0) {
			b->col = 240;
			b->row += 1;
		}

	}
}

void drawFruits(FRUIT* f) {
	if (f->active) {
		if (f->fruitType == 0) {
			drawImage4(f->col, f->row, f->width, f->height, appleBitmap);
		} else if (f->fruitType == 1) {
			drawImage4(f->col, f->row, f->width, f->height, kiwiBitmap);
		} else {
			drawImage4(f->col, f->row, f->width, f->height, orangeBitmap);
		}
	}
}