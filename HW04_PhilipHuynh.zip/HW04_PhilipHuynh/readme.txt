This game is a modified version of Breakout. The fruits are scrolling across the screen and move with the left and right arrow keys. 
Press Enter to start and once in the game state, press Enter again to Pause. Break all the fruits to win! Let the ball hit the bottom 
red bar and lose! 