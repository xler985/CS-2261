
//{{BLOCK(apple)

//======================================================================
//
//	apple, 20x20@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 400 = 912
//
//	Time-stamp: 2019-10-11, 16:56:12
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_APPLE_H
#define GRIT_APPLE_H

#define appleBitmapLen 400
extern const unsigned short appleBitmap[200];

#define applePalLen 512
extern const unsigned short applePal[256];

#endif // GRIT_APPLE_H

//}}BLOCK(apple)
