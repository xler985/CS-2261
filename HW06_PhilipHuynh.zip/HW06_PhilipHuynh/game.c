#include <stdio.h>
#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "spritesheet.h"
#include "math.h"

SHIP ship;
BULLET bullets[BULLETCOUNT];
BULLETEVIL bulletsEvil[BULLETCOUNT]; 
ALIEN aliens[ALIENCOUNT];
int aliensRemaining;
int livesRemaining;

OBJ_ATTR shadowOAM[128];

// Initialize the game
void initGame() {
	initShip();
	initBullets();
	initBulletsEvil();
	initaliens();
	DMANow(3, spritesheetPal, SPRITEPALETTE, 256);
	DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
	aliensRemaining = ALIENCOUNT;
	livesRemaining = 3;
}

// Updates the game each frame
void updateGame() {
	updateShip();
	for (int i = 0; i < BULLETCOUNT; i++) {
		updateBullet(&(bullets[i]));	
	} 
	for (int i =0; i < BULLETCOUNT; i++) {
		updateBulletEvil(&bulletsEvil[i]);
	}
	for (int i = 0; i < ALIENCOUNT; i++) {
		updateAlien(&(aliens[i]));	
	}

}

// Draws the game each frame
void drawGame() {
	drawShip();
	for (int i = 0; i < BULLETCOUNT; i++) {
		drawBullet(&(bullets[i]));
	}
	for (int i = 0; i < BULLETCOUNT; i++) {
		drawBulletEvil(&(bulletsEvil[i]));
	}
	for (int i = 0; i < ALIENCOUNT; i++) {
		drawAlien(&(aliens[i]));
	}
	drawLives();
	waitForVBlank();
    DMANow(3, shadowOAM, OAM, (128 * 4));
}


// Initialize the ship
void initShip() {
 	ship.row = 130;
 	ship.col = 130;
 	ship.cdel = 1;
	ship.rdel = 1;
 	ship.height = 32;
 	ship.width = 32;
	ship.aniCounter = 0;
    ship.curFrame = 0;
    ship.numFrames = 3;
 	ship.bulletTimer = 20;
}

// Handle every-frame actions of the ship
void updateShip() {
	if(ship.aniCounter % 20 == 0) {
			ship.curFrame = ship.aniCounter % 3;
		}
	if (BUTTON_HELD(BUTTON_LEFT) && ship.col >= ship.cdel) {
		ship.col -= ship.cdel;
	}
	if (BUTTON_HELD(BUTTON_RIGHT) && ship.col + ship.width - 1 < SCREENWIDTH - ship.cdel) {
		ship.col += ship.cdel;
	}

	// Fire bullets
	if (BUTTON_PRESSED(BUTTON_A) && ship.bulletTimer >= 15) {
 		fireBullet(); 
 		ship.bulletTimer = 0;
	}
	ship.bulletTimer++;
}
void drawLives () {
	for (int i = 0; i < livesRemaining; i++) {
		shadowOAM[i + 36].attr0 = (130) | ATTR0_4BPP | ATTR0_SQUARE;
		shadowOAM[i + 36].attr1 = (10 + (10 * i)) | ATTR1_TINY;
		shadowOAM[i + 36].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(9, 2);
	}
}
// Draw the player
void drawShip() {
	shadowOAM[0].attr0 = (0xFF & ship.row) | ATTR0_4BPP | ATTR0_SQUARE;
	shadowOAM[0].attr1 = (0x1FF & ship.col) | ATTR1_MEDIUM;
	shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 0);
}

// Initialize the pool of bullets
void initBullets() {
	for (int i = 0; i < BULLETCOUNT; i++) {
		bullets[i].height = 8;
		bullets[i].width = 8;
		bullets[i].row = (ship.row);
		bullets[i].col = ship.col;
		bullets[i].rdel = -2;
		bullets[i].active = 0;
		bullets[i].id = i;
	}
}


// Spawn a bullet
void fireBullet() {
	for (int i = 0; i < BULLETCOUNT; i++) { // Loop through the pool
		if (!(bullets[i].active)) {  // Find the first inactive
			bullets[i].row = ship.row;
			bullets[i].col = ship.col + (ship.width / 2) - (bullets[i].width);

			bullets[i].active = 1;   
			break;               
		}
	}
}

// // Handle every-frame actions of a bullet
void updateBullet(BULLET* b) {
	if ((b->active) == 1) {
			(b->row) += (b->rdel);	
	}
	if (((b->col) < 0) || (b->col > SCREENWIDTH -1) || (b->row < 0) || (b->row > SCREENHEIGHT - 1)) {
		b->active = 0;
	}

}

// // Draw a bullet
void drawBullet(BULLET* b) {
	if (b->active == 1) {
			shadowOAM[(b->id)+1].attr0 = b->row | ATTR0_4BPP | ATTR0_SQUARE;
			shadowOAM[(b->id)+1].attr1 = b->col | ATTR1_SMALL;
			shadowOAM[(b->id)+1].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(8, 0);
	} else {
		shadowOAM[(b->id)+1].attr0 = ATTR0_HIDE;
	} 
}

// Initialize the aliens
void initaliens() {
	for (int i = 0; i < ALIENCOUNT; i++) {
		aliens[i].height = 8;
		aliens[i].width = 8;
		aliens[i].alienType = rand() % 3;
		aliens[i].active = 1;
		aliens[i].id = i;
		aliens[i].bulletTimer = rand() % 220;
		aliens[i].aniCounter = 0;
		aliens[i].aniFrame = 0;
		aliens[i].cdel = 1;
		aliens[i].rdel = 2;
		aliens[i].moveCounter = 0;
	}
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			aliens[(i*5)+j].col = i*50 + 13;
			aliens[(i*5)+j].row = j*20 + 6;
			aliens[(i*5)+j].rank = i;
			aliens[(i*5)+j].lCommand = 0;
			aliens[(i*5)+j].rCommand = 0;
		}
	}
	aliens[24].rCommand = 1;
	aliens[4].lCommand = 1;
}

// Handle every-frame actions of a alien
void updateAlien(ALIEN* a) {
	if (a->active) {
		// Handle bullets[i]-bullet collisions
		if ((collision(a->col, a->row, a->width, a->height, 
			ship.col, ship.row, ship.width, ship.height)) || a->row >= 135) {
				livesRemaining = 0;
			}
		for (int i = 0; i < BULLETCOUNT; i++) {
			if ((collision(a->col, a->row, a->width, a->height, 
			bullets[i].col, bullets[i].row, bullets[i].width, bullets[i].height)))  {
				a->active = 0;
				if (a->lCommand) {
					for (int i = 0; i < 5; i++) {
						for (int j = 4; j >= 0; j--) {
							if (aliens[(i*5) + j].active) {
								aliens[(i*5) + j].lCommand = 1;
								aliens[a->id].lCommand = 0;
							}
						}
					}
				} else if (a->rCommand) {
					for (int i = a->id - 1; i >= 0; i--) {
						if (aliens[i].active) {
							aliens[i].rCommand = 1;
							aliens[a->id].rCommand = 0;
						}
					}
				}
				bullets[i].active = 0;
				aliensRemaining--;
			}
		}
			
		if (a->moveCounter > 50) {
			a->col += a->cdel;
			if (a->lCommand && a->col <= 2) {
				for (int i = 0; i < ALIENCOUNT; i++) {
					aliens[i].row += aliens[i].rdel;
					aliens[i].cdel *= -1;
				}
			} else if (a->rCommand && a->col > 224) {
				for (int i = 0; i < ALIENCOUNT; i++) {
					aliens[i].row += aliens[i].rdel;
					aliens[i].cdel *= -1;
					
				}
			}
			a->moveCounter = 0;
		} else {
			a->moveCounter++;
		}
		
		if (a->bulletTimer >= 380) {
			a->aniCounter = 1;
			a->aniFrame = 1;
			fireBulletEvil(a);  
 			a->bulletTimer = 0;
		} else {
			a->bulletTimer++;
		}

		if (a->aniCounter > 0) {
			a->aniCounter++;
		}
		if (a->aniCounter >= 50) {
			a->aniCounter = -1;
			a->aniFrame = 0;
		}
		
	}
}

// Draw a bullets[i]
void drawAlien(ALIEN* b) {
		if (b->active) {
			shadowOAM[b->id + 6].attr0 = (0xFF & b->row) | ATTR0_4BPP | ATTR0_SQUARE;
			shadowOAM[b->id + 6].attr1 = (0x1FF & b->col) | ATTR1_SMALL;
			shadowOAM[b->id + 6].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(10 + (b->aniFrame * 2), b->alienType * 2);
		} else {
			shadowOAM[b->id + 6].attr0 = ATTR0_HIDE;
		}
	
}

void initBulletsEvil() {
	for (int i = 0; i < BULLETCOUNT; i++) {
		bulletsEvil[i].height = 8;
		bulletsEvil[i].width = 4;
		bulletsEvil[i].row = 10;
		bulletsEvil[i].col = 10;
		bulletsEvil[i].rdel = 1;
		bulletsEvil[i].active = 0;
		bulletsEvil[i].id = i+1;
	}
}

void fireBulletEvil(ALIEN* a) {
	if (a-> active) {
		for (int i = 0; i < BULLETCOUNT; i++) { // Loop through the pool
			if (!(bulletsEvil[i].active)) {  // Find the first inactive
				bulletsEvil[i].row = a->row;
				bulletsEvil[i].col = a->col + (a->width / 2) + 1;
				bulletsEvil[i].active = 1;   
				break;               
			}
		}
		for (volatile int i = 0; i < 50; i++) {

		}
	}
} 

// // Handle every-frame actions of a bullet
void updateBulletEvil(BULLETEVIL* e) {
	if ((e->active)) {
		(e->row) += (e->rdel);	
		if ((collision(ship.col, ship.row, ship.width, ship.height, e->col, e->row, e->width, e->height)))  {
			e->active = 0;
			// Update the score
			shadowOAM[livesRemaining - 1 + 36].attr0 = ATTR0_HIDE;
			livesRemaining--;

		}
	}
	if (((e->col) < 0) || (e->col > SCREENWIDTH -1) || (e->row < 0) || (e->row > SCREENHEIGHT - 1)) {
		e->active = 0;
	}
		

}

// Draw a bullet
void drawBulletEvil(BULLETEVIL* b) {
	if (b->active == 1) {
			shadowOAM[(b->id)+30].attr0 = b->row | ATTR0_4BPP | ATTR0_TALL;
			shadowOAM[(b->id)+30].attr1 = b->col | ATTR1_TINY;
			shadowOAM[(b->id)+30].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(8, 2); 
	} else {
		shadowOAM[(b->id)+30].attr0 = ATTR0_HIDE;
	}
	 
}