
//{{BLOCK(pauseScreen)

//======================================================================
//
//	pauseScreen, 256x256@4, 
//	+ 31 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 992 + 2048 = 3040
//
//	Time-stamp: 2019-10-25, 20:49:13
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAUSESCREEN_H
#define GRIT_PAUSESCREEN_H

#define pauseScreenTilesLen 992
extern const unsigned short pauseScreenTiles[496];

#define pauseScreenMapLen 2048
extern const unsigned short pauseScreenMap[1024];

#endif // GRIT_PAUSESCREEN_H

//}}BLOCK(pauseScreen)
