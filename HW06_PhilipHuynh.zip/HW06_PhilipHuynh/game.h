OBJ_ATTR shadowOAM[128];

//Ship Struct
typedef struct {
	int row;
	int col;
	int cdel;
	int rdel;
	int height;
	int width;
	int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
	int bulletTimer;
} SHIP;


// Bullet Struct
typedef struct {
	int row;
	int col;
	int rdel;
	int height;
	int width;
	int active;
	int id;
} BULLET;


// alien Struct
typedef struct {
	int row;
	int col;
	int rdel;
	int cdel;
	int height;
	int width;
	int active;
	int aniCounter;
	int alienType;
	int id;
	int bulletTimer;
	int aniFrame;
	int rank;
	int lCommand;
	int rCommand;
	int moveCounter;
} ALIEN;

// Alien Bullet Struct
typedef struct {
	int row;
	int col;
	int rdel;
	int height;
	int width;
	int active;
	int id;
} BULLETEVIL;



// Constants
#define BULLETCOUNT 5
#define ALIENCOUNT 25

// Variables
extern SHIP ship;
extern BULLET bullets[BULLETCOUNT];
extern BULLETEVIL bulletsEvil[BULLETCOUNT];
extern ALIEN aliens[ALIENCOUNT];
extern int aliensRemaining;
extern int livesRemaining;

// Prototypes
void initGame();
void updateGame();
void drawGame();
void drawLives();
void initShip();
void updateShip();
void drawShip();

void initBullets();
void fireBullet();
void updateBullet(BULLET *);
void drawBullet(BULLET *);
void initaliens();
void updateAlien(ALIEN *);
void drawAlien(ALIEN *);
void initBulletsEvil();
void fireBulletEvil(ALIEN *);
void updateBulletEvil(BULLETEVIL *);
void drawBulletEvil(BULLETEVIL *);
