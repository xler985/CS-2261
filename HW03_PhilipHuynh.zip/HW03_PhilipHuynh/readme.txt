The game is called "Asteroids...Kinda"
You play as a ship dodging "asteroids" (rectangles) and shooting these asteroids to complete the game.
They are always 5 asteroids to destroy, with various sides that randomize per game. 
You have to press the A button (the X key on the keyboard) shoot bullets and destroy the asteroids. (You can only shoot to the left for now).
You move with the arrow keys and have to avoid the asteroids while destroying them.
You can pause with the start button once you are in the game.
If you collide with the asteroids, you will recieve a lose screen
If you destroy the asteroids, you will recieve a win screen.