#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "screen.h"

SHIP ship;
BULLET bullets[BULLETCOUNT];
BALL balls[BALLCOUNT];
int ballsRemaining;


// Initialize the game
void initGame() {
	initShip();

	
	initBullets();

	initBalls();
	ballsRemaining = BALLCOUNT;
}

// Updates the game each frame
void updateGame() {

	updateShip();
	for (int i = 0; i < BULLETCOUNT; i++) {
		updateBullet(&(bullets[i]));	
	}
	
	for (int i = 0; i < BALLCOUNT; i++) {
		updateBall(&(balls[i]));	
	}

}

// Draws the game each frame
void drawGame() {
	drawShip();

	for (int i =0; i < BULLETCOUNT; i++) {
		drawBullet(&(bullets[i]));
	}

	for (int i =0; i < BALLCOUNT; i++) {
		drawBall(&(balls[i]));
	}

}


// Initialize the ship
void initShip() {

 	ship.row = 120;
 	ship.col = 200;
 	ship.oldRow = ship.row;
 	ship.oldCol = ship.col;
 	ship.cdel = 1;
	ship.rdel = 1;
 	ship.height = 5;
 	ship.width = 6;
 	ship.bulletTimer = 20;
}

// Handle every-frame actions of the ship
void updateShip() {
	// Move the ship
	if (BUTTON_HELD(BUTTON_LEFT) && ship.col >= ship.cdel) {
		ship.col -= ship.cdel;
	}
	if (BUTTON_HELD(BUTTON_RIGHT) && ship.col + ship.width - 1 < SCREENWIDTH - ship.cdel) {
		ship.col += ship.cdel;
	}
	if (BUTTON_HELD(BUTTON_UP) && ship.row >= ship.rdel) {
		ship.row -= ship.rdel;
	}
	if (BUTTON_HELD(BUTTON_DOWN) && ship.row + ship.height - 1 < SCREENHEIGHT - ship.rdel) {
		ship.row += ship.rdel;
	}

	// Fire bullets
	if (BUTTON_PRESSED(BUTTON_A) && ship.bulletTimer >= 15) {
		
 		fireBullet(); 
 		ship.bulletTimer = 0;
	}
	ship.bulletTimer++;
}

// Draw the player
void drawShip() {
	drawRect(ship.oldCol, ship.oldRow, ship.width, ship.height, BLACK);
	drawShipShape(ship.col, ship.row);

	ship.oldRow = ship.row;
	ship.oldCol = ship.col;
}

// Initialize the pool of bullets
void initBullets() {
	for (int i = 0; i < BULLETCOUNT; i++) {
		bullets[i].height = 2;
		bullets[i].width = 1;
		bullets[i].row = -(bullets[i].height);
		bullets[i].col = 0;
		bullets[i].oldRow = (bullets[i].row);
		bullets[i].oldCol = (bullets[i].col);
		bullets[i].rdel = -2;
		bullets[i].cdel = -2;
		bullets[i].color = WHITE;
		bullets[i].active = 0;
	}
}

// Spawn a bullet
void fireBullet() {
	for (int i = 0; i < BULLETCOUNT; i++) { // Loop through the pool
		if (!bullets[i].active) {  // Find the first inactive
			bullets[i].row = ship.row;
			bullets[i].col = ship.col + (ship.width / 2) + (bullets[i].width / 2);

			bullets[i].active = 1;   
			bullets[i].erased = 0;
			break;               
		}
	}

}

// // Handle every-frame actions of a bullet
void updateBullet(BULLET* b) {
	if ((b->active) == 1) {
		(b->col) += (b->cdel);
	}
	if (((b->col) < 0) || (b->col > SCREENWIDTH -1) || (b->row < 0) || (b->row > SCREENHEIGHT - 1)) {
		b->active = 0;
	}

}

// // Draw a bullet
void drawBullet(BULLET* b) {
	if(b->active) {
 		drawRect(b->oldCol, b->oldRow, b->width, b->height, BLACK);
		drawRect(b->col, b->row, b->width, b->height, b->color);
 	} else if (!b->erased) {
 		drawRect(b->oldCol, b->oldRow, b->width, b->height, BLACK);
 		b->erased = 1;
 	}
 	b->oldRow = b->row;
 	b->oldCol = b->col;
}

// Initialize the balls
void initBalls() {

	for (int i = 0; i < BALLCOUNT; i++) {
		balls[i].height = (rand() % 5) + 10;
		balls[i].width = (rand() % 5) + 10 ;
		balls[i].row = rand() % 110;
		balls[i].col = rand() % 130;
		balls[i].oldRow = balls[i].row;
		balls[i].oldCol = balls[i].col;
		balls[i].rdel = 1;
		balls[i].cdel = 1;
		balls[i].color = BLUE;
		balls[i].active = 1;
		balls[i].erased = 0;
	}
}

// Handle every-frame actions of a ball
void updateBall(BALL* b) {

	if (b->active) {

		// Bounce the ball off the sides of the box
		if (b->row <= 0 || b->row + b->height-1 >= SCREENHEIGHT - 1)
			b->rdel *= -1;
		if (b->col <= 0 || b->col + b->width-1 >= SCREENWIDTH-1)
			b->cdel *= -1;

		// Move the ball
		b->row += b->rdel;
		b->col += b->cdel;

		// Handle ball-bullet collisions
		for (int i = 0;i < BULLETCOUNT; i++) {
			if (bullets[i].active == 1 && 
				(collision(bullets[i].col, bullets[i].row, bullets[i].width, bullets[i].height, b->col, b->row, b->width, b->height))) {
					bullets[i].active = 0;
					b->active = 0;
					ballsRemaining -= 1;
				}
		}

		//Handles Collision with Ship	
		if (collision(ship.col, ship.row, ship.width, ship.height, b->col,b->row, b->width, b->height)) {
			ballsRemaining = -1;
		}
	}
}

// Draw a ball
void drawBall(BALL* b) {
	if(b->active) {
		drawRect(b->oldCol, b->oldRow, b->width, b->height, BLACK);
		drawRect(b->col, b->row, b->width, b->height, b->color);
	} else if (!b->erased) {
		drawRect(b->oldCol, b->oldRow, b->width, b->height, BLACK);
		b->erased = 1;
	}
	b->oldRow = b->row;
	b->oldCol = b->col;
}