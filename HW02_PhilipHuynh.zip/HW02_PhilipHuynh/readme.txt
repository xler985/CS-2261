The game is called "Dimensional Dodge"
You play as a ship dodging "asteroids" (rectangles) and 
trying to survive until your hyperdrive is ready (survive for about an minute).
They are always 2 visible asteroids and 2 "invisible" asteroids (asteroids that are the same color as the backgrond)
You have to press the A button (the X key on the keyboard) repeatedly to "switch between dimensions" (change background color) to avoid all the rectangles
You move with the arrow keys and have to avoid the asteroids.
If you collide with the rectangles, you will recieve a lose screen
If you survive for a minute, you will recieve a win screen.
In both scenarios the game screen will turn black after a small time has passed.