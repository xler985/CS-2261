#include "myLib.h"

unsigned short *videoBuffer = (unsigned short *)0x6000000;

void setPixel(int col, int row, unsigned short color) {
	videoBuffer[OFFSET(col, row, SCREENWIDTH)] = color;
}

void drawRect(int col, int row, int width, int height, unsigned short color) {
    for (int j = 0; j < height; j++) {
        for (int i = 0; i < width; i++) {
            setPixel((col + i), (row + j), color);
        }
    }
}
void drawShip(int col, int row) {
    for (int j = 0; j < 5; j +=4) {
        setPixel((col + 0), (row + j), GREEN);
        setPixel((col + 1), (row + j), BLUE);
        setPixel((col + 2), (row + j), GREEN);
        setPixel((col + 3), (row + j), GREEN);
        setPixel((col + 4), (row + j), BLUE);
        setPixel((col + 5), (row + j), GREEN);
    }
    for (int j = 1; j < 4; j +=2) {
        setPixel((col + 0), (row + j), BLUE);
        setPixel((col + 1), (row + j), GREEN);
        setPixel((col + 2), (row + j), WHITE);
        setPixel((col + 3), (row + j), WHITE);
        setPixel((col + 4), (row + j), GREEN);
        setPixel((col + 5), (row + j), BLUE);
    }
    setPixel((col + 0), (row + 2), GREEN);
    setPixel((col + 1), (row + 2), WHITE);
    setPixel((col + 2), (row + 2), BLUE);
    setPixel((col + 3), (row + 2), BLUE);
    setPixel((col + 4), (row + 2), WHITE);
    setPixel((col + 5), (row + 2), GREEN);
}


void fillScreen(unsigned short color) {
    for (int i = 0; i < 86400; i++) {
        videoBuffer[i] = color;
    }  
}

void waitForVBlank() {
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

int collision(int colA, int rowA, int widthA, int heightA, int colB, int rowB, int widthB, int heightB) {
    if ((((colA + widthA) > colB) && (colA < (colB + widthB))) &&(((rowA + heightA) > rowB) && (rowA < (rowB + heightB)))) {
        return 1;
    } else{
        return 0;
    }
}

void drawEndScreen() {
    setPixel(100, 47, MAGENTA);
    setPixel(104, 47, MAGENTA);
    setPixel(107, 47, MAGENTA);
    setPixel(108, 47, MAGENTA);
    setPixel(111, 47, MAGENTA);
    setPixel(114, 47, MAGENTA);
    setPixel(121, 47, MAGENTA);
    setPixel(127, 47, MAGENTA);
    setPixel(128, 47, MAGENTA);
    setPixel(104, 47, MAGENTA);
    setPixel(132, 47, MAGENTA);
    setPixel(133, 47, MAGENTA);
    setPixel(134, 47, MAGENTA);
    setPixel(136, 47, MAGENTA);
    setPixel(137, 47, MAGENTA);
    setPixel(138, 47, MAGENTA);
    setPixel(139, 47, MAGENTA);
    setPixel(141, 47, MAGENTA);

    setPixel(100, 48, MAGENTA);
    setPixel(104, 48, MAGENTA);
    setPixel(106, 48, MAGENTA);
    setPixel(109, 48, MAGENTA);
    setPixel(111, 48, MAGENTA);
    setPixel(114, 48, MAGENTA);
    setPixel(121, 48, MAGENTA);
    setPixel(126, 48, MAGENTA);
    setPixel(129, 48, MAGENTA);
    setPixel(131, 48, MAGENTA);
    setPixel(136, 48, MAGENTA);
    setPixel(141, 48, MAGENTA);

    setPixel(101, 49, MAGENTA);
    setPixel(102, 49, MAGENTA);
    setPixel(103, 49, MAGENTA);
    setPixel(106, 49, MAGENTA);
    setPixel(109, 49, MAGENTA);
    setPixel(111, 49, MAGENTA);
    setPixel(114, 49, MAGENTA);
    setPixel(121, 49, MAGENTA);
    setPixel(126, 49, MAGENTA);
    setPixel(129, 49, MAGENTA);
    setPixel(132, 49, MAGENTA);
    setPixel(133, 49, MAGENTA);
    setPixel(136, 49, MAGENTA);
    setPixel(137, 49, MAGENTA);
    setPixel(138, 49, MAGENTA);
    setPixel(141, 49, MAGENTA);

    setPixel(102, 50, MAGENTA);
    setPixel(106, 50, MAGENTA);
    setPixel(109, 50, MAGENTA);
    setPixel(111, 50, MAGENTA);
    setPixel(114, 50, MAGENTA);
    setPixel(121, 50, MAGENTA);
    setPixel(126, 50, MAGENTA);
    setPixel(129, 50, MAGENTA);
    setPixel(134, 50, MAGENTA);
    setPixel(136, 50, MAGENTA);

    setPixel(102, 51, MAGENTA);
    setPixel(107, 51, MAGENTA);
    setPixel(108, 51, MAGENTA);
    setPixel(112, 51, MAGENTA);
    setPixel(113, 51, MAGENTA);
    setPixel(121, 51, MAGENTA);
    setPixel(122, 51, MAGENTA);
    setPixel(123, 51, MAGENTA);
    setPixel(124, 51, MAGENTA);
    setPixel(127, 51, MAGENTA);
    setPixel(128, 51, MAGENTA);
    setPixel(131, 51, MAGENTA);
    setPixel(132, 51, MAGENTA);
    setPixel(133, 51, MAGENTA);
    setPixel(136, 51, MAGENTA);
    setPixel(137, 51, MAGENTA);
    setPixel(138, 51, MAGENTA);
    setPixel(139, 51, MAGENTA);
    setPixel(141, 51, MAGENTA);
    
    setPixel(78, 62, MAGENTA);
    setPixel(79, 62, MAGENTA);
    setPixel(80, 62, MAGENTA);
    setPixel(81, 62, MAGENTA);
    setPixel(83, 62, MAGENTA);
    setPixel(86, 62, MAGENTA);
    setPixel(88, 62, MAGENTA);
    setPixel(89, 62, MAGENTA);
    setPixel(90, 62, MAGENTA);
    setPixel(92, 62, MAGENTA);
    setPixel(93, 62, MAGENTA);
    setPixel(94, 62, MAGENTA);
    setPixel(95, 62, MAGENTA);
    setPixel(96, 62, MAGENTA);
    setPixel(104, 62, MAGENTA);
    setPixel(105, 62, MAGENTA);
    setPixel(108, 62, MAGENTA);
    setPixel(111, 62, MAGENTA);
    setPixel(113, 62, MAGENTA);
    setPixel(114, 62, MAGENTA);
    setPixel(115, 62, MAGENTA);
    setPixel(123, 62, MAGENTA);
    setPixel(124, 62, MAGENTA);
    setPixel(125, 62, MAGENTA);
    setPixel(126, 62, MAGENTA);
    setPixel(127, 62, MAGENTA);
    setPixel(129, 62, MAGENTA);
    setPixel(130, 62, MAGENTA);
    setPixel(131, 62, MAGENTA);
    setPixel(134, 62, MAGENTA);
    setPixel(138, 62, MAGENTA);
    setPixel(146, 62, MAGENTA);
    setPixel(147, 62, MAGENTA);
    setPixel(151, 62, MAGENTA);
    setPixel(152, 62, MAGENTA);
    setPixel(156, 62, MAGENTA);
    setPixel(157, 62, MAGENTA);
    setPixel(160, 62, MAGENTA);
    setPixel(161, 62, MAGENTA);
    setPixel(162, 62, MAGENTA);
    setPixel(164, 62, MAGENTA);
    setPixel(167, 62, MAGENTA);
    setPixel(169, 62, MAGENTA);

    setPixel(78, 63, MAGENTA);
    setPixel(83, 63, MAGENTA);
    setPixel(86, 63, MAGENTA);
    setPixel(89, 63, MAGENTA);;
    setPixel(94, 63, MAGENTA);
    setPixel(103, 63, MAGENTA);
    setPixel(106, 63, MAGENTA);
    setPixel(108, 63, MAGENTA);
    setPixel(109, 63, MAGENTA);
    setPixel(111, 63, MAGENTA);
    setPixel(113, 63, MAGENTA);
    setPixel(116, 63, MAGENTA);
    setPixel(125, 63, MAGENTA);
    setPixel(129, 63, MAGENTA);
    setPixel(132, 63, MAGENTA);
    setPixel(134, 63, MAGENTA);
    setPixel(138, 63, MAGENTA);
    setPixel(145, 63, MAGENTA);
    setPixel(148, 63, MAGENTA);
    setPixel(150, 63, MAGENTA);
    setPixel(155, 63, MAGENTA);
    setPixel(158, 63, MAGENTA);
    setPixel(161, 63, MAGENTA);
    setPixel(164, 63, MAGENTA);
    setPixel(165, 63, MAGENTA);
    setPixel(167, 63, MAGENTA);
    setPixel(169, 63, MAGENTA);

    setPixel(78, 64, MAGENTA);
    setPixel(79, 64, MAGENTA);
    setPixel(80, 64, MAGENTA);
    setPixel(84, 64, MAGENTA);
    setPixel(85, 64, MAGENTA);
    setPixel(89, 64, MAGENTA);;
    setPixel(94, 64, MAGENTA);
    setPixel(103, 64, MAGENTA);
    setPixel(104, 64, MAGENTA);
    setPixel(105, 64, MAGENTA);
    setPixel(106, 64, MAGENTA);
    setPixel(108, 64, MAGENTA);
    setPixel(110, 64, MAGENTA);
    setPixel(111, 64, MAGENTA);
    setPixel(113, 64, MAGENTA);
    setPixel(116, 64, MAGENTA);
    setPixel(125, 64, MAGENTA);
    setPixel(129, 64, MAGENTA);
    setPixel(130, 64, MAGENTA);
    setPixel(131, 64, MAGENTA);
    setPixel(135, 64, MAGENTA);
    setPixel(136, 64, MAGENTA);
    setPixel(137, 64, MAGENTA);
    setPixel(145, 64, MAGENTA);
    setPixel(146, 64, MAGENTA);
    setPixel(147, 64, MAGENTA);
    setPixel(148, 64, MAGENTA);
    setPixel(150, 64, MAGENTA);
    setPixel(152, 64, MAGENTA);
    setPixel(153, 64, MAGENTA);
    setPixel(155, 64, MAGENTA);
    setPixel(156, 64, MAGENTA);
    setPixel(157, 64, MAGENTA);
    setPixel(158, 64, MAGENTA);
    setPixel(161, 64, MAGENTA);
    setPixel(164, 64, MAGENTA);
    setPixel(166, 64, MAGENTA);
    setPixel(167, 64, MAGENTA);
    setPixel(169, 64, MAGENTA);

    setPixel(78, 65, MAGENTA);
    setPixel(83, 65, MAGENTA);
    setPixel(86, 65, MAGENTA);
    setPixel(89, 65, MAGENTA);;
    setPixel(94, 65, MAGENTA);
    setPixel(103, 65, MAGENTA);
    setPixel(106, 65, MAGENTA);
    setPixel(108, 65, MAGENTA);
    setPixel(111, 65, MAGENTA);
    setPixel(113, 65, MAGENTA);
    setPixel(116, 65, MAGENTA);
    setPixel(125, 65, MAGENTA);
    setPixel(129, 65, MAGENTA);
    setPixel(131, 65, MAGENTA);
    setPixel(136, 65, MAGENTA);
    setPixel(145, 65, MAGENTA);
    setPixel(148, 65, MAGENTA);
    setPixel(150, 65, MAGENTA);
    setPixel(153, 65, MAGENTA);
    setPixel(155, 65, MAGENTA);
    setPixel(158, 65, MAGENTA);
    setPixel(161, 65, MAGENTA);
    setPixel(164, 65, MAGENTA);
    setPixel(167, 65, MAGENTA);
    
    setPixel(78, 66, MAGENTA);
    setPixel(79, 66, MAGENTA);
    setPixel(80, 66, MAGENTA);
    setPixel(81, 66, MAGENTA);
    setPixel(83, 66, MAGENTA);
    setPixel(86, 66, MAGENTA);
    setPixel(88, 66, MAGENTA);
    setPixel(89, 66, MAGENTA);
    setPixel(90, 66, MAGENTA);
    setPixel(94, 66, MAGENTA);
    setPixel(103, 66, MAGENTA);
    setPixel(106, 66, MAGENTA);
    setPixel(108, 66, MAGENTA);
    setPixel(111, 66, MAGENTA);
    setPixel(113, 66, MAGENTA);
    setPixel(114, 66, MAGENTA);
    setPixel(115, 66, MAGENTA);
    setPixel(125, 66, MAGENTA);
    setPixel(129, 66, MAGENTA);
    setPixel(132, 66, MAGENTA);
    setPixel(136, 66, MAGENTA);
    setPixel(145, 66, MAGENTA);
    setPixel(148, 66, MAGENTA);
    setPixel(151, 66, MAGENTA);
    setPixel(152, 66, MAGENTA);
    setPixel(155, 66, MAGENTA);
    setPixel(158, 66, MAGENTA);
    setPixel(160, 66, MAGENTA);
    setPixel(161, 66, MAGENTA);
    setPixel(162, 66, MAGENTA);
    setPixel(164, 66, MAGENTA);
    setPixel(167, 66, MAGENTA);
    setPixel(169, 66, MAGENTA);
}

void drawWinScreen() {
    setPixel(100, 47, MAGENTA);
    setPixel(104, 47, MAGENTA);
    setPixel(107, 47, MAGENTA);
    setPixel(108, 47, MAGENTA);
    setPixel(111, 47, MAGENTA);
    setPixel(114, 47, MAGENTA);
    setPixel(124, 47, MAGENTA);
    setPixel(128, 47, MAGENTA);
    setPixel(130, 47, MAGENTA);
    setPixel(131, 47, MAGENTA);
    setPixel(132, 47, MAGENTA);
    setPixel(133, 47, MAGENTA);
    setPixel(134, 47, MAGENTA);
    setPixel(137, 47, MAGENTA);
    setPixel(141, 47, MAGENTA);

    setPixel(100, 48, MAGENTA);
    setPixel(104, 48, MAGENTA);
    setPixel(106, 48, MAGENTA);
    setPixel(109, 48, MAGENTA);
    setPixel(111, 48, MAGENTA);
    setPixel(114, 48, MAGENTA);
    setPixel(124, 48, MAGENTA);
    setPixel(128, 48, MAGENTA);
    setPixel(131, 48, MAGENTA);
    setPixel(134, 48, MAGENTA);
    setPixel(135, 48, MAGENTA);
    setPixel(137, 48, MAGENTA);
    setPixel(141, 48, MAGENTA);

    setPixel(101, 49, MAGENTA);
    setPixel(102, 49, MAGENTA);
    setPixel(103, 49, MAGENTA);
    setPixel(106, 49, MAGENTA);
    setPixel(109, 49, MAGENTA);
    setPixel(111, 49, MAGENTA);
    setPixel(114, 49, MAGENTA);
    setPixel(124, 49, MAGENTA);
    setPixel(126, 49, MAGENTA);
    setPixel(128, 49, MAGENTA);
    setPixel(131, 49, MAGENTA);
    setPixel(134, 49, MAGENTA);
    setPixel(136, 49, MAGENTA);
    setPixel(137, 49, MAGENTA);
    setPixel(141, 49, MAGENTA);

    setPixel(102, 50, MAGENTA);
    setPixel(106, 50, MAGENTA);
    setPixel(109, 50, MAGENTA);
    setPixel(111, 50, MAGENTA);
    setPixel(114, 50, MAGENTA);
    setPixel(124, 50, MAGENTA);
    setPixel(125, 50, MAGENTA);
    setPixel(127, 50, MAGENTA);
    setPixel(128, 50, MAGENTA);
    setPixel(131, 50, MAGENTA);
    setPixel(134, 50, MAGENTA);
    setPixel(137, 50, MAGENTA);

    setPixel(102, 51, MAGENTA);
    setPixel(107, 51, MAGENTA);
    setPixel(108, 51, MAGENTA);
    setPixel(112, 51, MAGENTA);
    setPixel(113, 51, MAGENTA);
    setPixel(124, 51, MAGENTA);
    setPixel(128, 51, MAGENTA);
    setPixel(130, 51, MAGENTA);
    setPixel(131, 51, MAGENTA);
    setPixel(132, 51, MAGENTA);
    setPixel(134, 51, MAGENTA);
    setPixel(137, 51, MAGENTA);
    setPixel(141, 51, MAGENTA);
    
    setPixel(78, 62, MAGENTA);
    setPixel(79, 62, MAGENTA);
    setPixel(80, 62, MAGENTA);
    setPixel(81, 62, MAGENTA);
    setPixel(83, 62, MAGENTA);
    setPixel(86, 62, MAGENTA);
    setPixel(88, 62, MAGENTA);
    setPixel(89, 62, MAGENTA);
    setPixel(90, 62, MAGENTA);
    setPixel(92, 62, MAGENTA);
    setPixel(93, 62, MAGENTA);
    setPixel(94, 62, MAGENTA);
    setPixel(95, 62, MAGENTA);
    setPixel(96, 62, MAGENTA);
    setPixel(104, 62, MAGENTA);
    setPixel(105, 62, MAGENTA);
    setPixel(108, 62, MAGENTA);
    setPixel(111, 62, MAGENTA);
    setPixel(113, 62, MAGENTA);
    setPixel(114, 62, MAGENTA);
    setPixel(115, 62, MAGENTA);
    setPixel(123, 62, MAGENTA);
    setPixel(124, 62, MAGENTA);
    setPixel(125, 62, MAGENTA);
    setPixel(126, 62, MAGENTA);
    setPixel(127, 62, MAGENTA);
    setPixel(129, 62, MAGENTA);
    setPixel(130, 62, MAGENTA);
    setPixel(131, 62, MAGENTA);
    setPixel(134, 62, MAGENTA);
    setPixel(138, 62, MAGENTA);
    setPixel(146, 62, MAGENTA);
    setPixel(147, 62, MAGENTA);
    setPixel(151, 62, MAGENTA);
    setPixel(152, 62, MAGENTA);
    setPixel(156, 62, MAGENTA);
    setPixel(157, 62, MAGENTA);
    setPixel(160, 62, MAGENTA);
    setPixel(161, 62, MAGENTA);
    setPixel(162, 62, MAGENTA);
    setPixel(164, 62, MAGENTA);
    setPixel(167, 62, MAGENTA);
    setPixel(169, 62, MAGENTA);

    setPixel(78, 63, MAGENTA);
    setPixel(83, 63, MAGENTA);
    setPixel(86, 63, MAGENTA);
    setPixel(89, 63, MAGENTA);;
    setPixel(94, 63, MAGENTA);
    setPixel(103, 63, MAGENTA);
    setPixel(106, 63, MAGENTA);
    setPixel(108, 63, MAGENTA);
    setPixel(109, 63, MAGENTA);
    setPixel(111, 63, MAGENTA);
    setPixel(113, 63, MAGENTA);
    setPixel(116, 63, MAGENTA);
    setPixel(125, 63, MAGENTA);
    setPixel(129, 63, MAGENTA);
    setPixel(132, 63, MAGENTA);
    setPixel(134, 63, MAGENTA);
    setPixel(138, 63, MAGENTA);
    setPixel(145, 63, MAGENTA);
    setPixel(148, 63, MAGENTA);
    setPixel(150, 63, MAGENTA);
    setPixel(155, 63, MAGENTA);
    setPixel(158, 63, MAGENTA);
    setPixel(161, 63, MAGENTA);
    setPixel(164, 63, MAGENTA);
    setPixel(165, 63, MAGENTA);
    setPixel(167, 63, MAGENTA);
    setPixel(169, 63, MAGENTA);

    setPixel(78, 64, MAGENTA);
    setPixel(79, 64, MAGENTA);
    setPixel(80, 64, MAGENTA);
    setPixel(84, 64, MAGENTA);
    setPixel(85, 64, MAGENTA);
    setPixel(89, 64, MAGENTA);;
    setPixel(94, 64, MAGENTA);
    setPixel(103, 64, MAGENTA);
    setPixel(104, 64, MAGENTA);
    setPixel(105, 64, MAGENTA);
    setPixel(106, 64, MAGENTA);
    setPixel(108, 64, MAGENTA);
    setPixel(110, 64, MAGENTA);
    setPixel(111, 64, MAGENTA);
    setPixel(113, 64, MAGENTA);
    setPixel(116, 64, MAGENTA);
    setPixel(125, 64, MAGENTA);
    setPixel(129, 64, MAGENTA);
    setPixel(130, 64, MAGENTA);
    setPixel(131, 64, MAGENTA);
    setPixel(135, 64, MAGENTA);
    setPixel(136, 64, MAGENTA);
    setPixel(137, 64, MAGENTA);
    setPixel(145, 64, MAGENTA);
    setPixel(146, 64, MAGENTA);
    setPixel(147, 64, MAGENTA);
    setPixel(148, 64, MAGENTA);
    setPixel(150, 64, MAGENTA);
    setPixel(152, 64, MAGENTA);
    setPixel(153, 64, MAGENTA);
    setPixel(155, 64, MAGENTA);
    setPixel(156, 64, MAGENTA);
    setPixel(157, 64, MAGENTA);
    setPixel(158, 64, MAGENTA);
    setPixel(161, 64, MAGENTA);
    setPixel(164, 64, MAGENTA);
    setPixel(166, 64, MAGENTA);
    setPixel(167, 64, MAGENTA);
    setPixel(169, 64, MAGENTA);

    setPixel(78, 65, MAGENTA);
    setPixel(83, 65, MAGENTA);
    setPixel(86, 65, MAGENTA);
    setPixel(89, 65, MAGENTA);;
    setPixel(94, 65, MAGENTA);
    setPixel(103, 65, MAGENTA);
    setPixel(106, 65, MAGENTA);
    setPixel(108, 65, MAGENTA);
    setPixel(111, 65, MAGENTA);
    setPixel(113, 65, MAGENTA);
    setPixel(116, 65, MAGENTA);
    setPixel(125, 65, MAGENTA);
    setPixel(129, 65, MAGENTA);
    setPixel(131, 65, MAGENTA);
    setPixel(136, 65, MAGENTA);
    setPixel(145, 65, MAGENTA);
    setPixel(148, 65, MAGENTA);
    setPixel(150, 65, MAGENTA);
    setPixel(153, 65, MAGENTA);
    setPixel(155, 65, MAGENTA);
    setPixel(158, 65, MAGENTA);
    setPixel(161, 65, MAGENTA);
    setPixel(164, 65, MAGENTA);
    setPixel(167, 65, MAGENTA);
    
    setPixel(78, 66, MAGENTA);
    setPixel(79, 66, MAGENTA);
    setPixel(80, 66, MAGENTA);
    setPixel(81, 66, MAGENTA);
    setPixel(83, 66, MAGENTA);
    setPixel(86, 66, MAGENTA);
    setPixel(88, 66, MAGENTA);
    setPixel(89, 66, MAGENTA);
    setPixel(90, 66, MAGENTA);
    setPixel(94, 66, MAGENTA);
    setPixel(103, 66, MAGENTA);
    setPixel(106, 66, MAGENTA);
    setPixel(108, 66, MAGENTA);
    setPixel(111, 66, MAGENTA);
    setPixel(113, 66, MAGENTA);
    setPixel(114, 66, MAGENTA);
    setPixel(115, 66, MAGENTA);
    setPixel(125, 66, MAGENTA);
    setPixel(129, 66, MAGENTA);
    setPixel(132, 66, MAGENTA);
    setPixel(136, 66, MAGENTA);
    setPixel(145, 66, MAGENTA);
    setPixel(148, 66, MAGENTA);
    setPixel(151, 66, MAGENTA);
    setPixel(152, 66, MAGENTA);
    setPixel(155, 66, MAGENTA);
    setPixel(158, 66, MAGENTA);
    setPixel(160, 66, MAGENTA);
    setPixel(161, 66, MAGENTA);
    setPixel(162, 66, MAGENTA);
    setPixel(164, 66, MAGENTA);
    setPixel(167, 66, MAGENTA);
    setPixel(169, 66, MAGENTA);
}


