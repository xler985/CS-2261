#include "myLib.h"

// Prototypes
void initialize();
void update();
void draw();

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

// Background Variables
unsigned short bgColor;

// Red Rectangle 1 Variables
int r1Col;
int r1Row;
int r1OldCol;
int r1OldRow;
int r1CDel;
int r1RDel;
int r1Width;
int r1Height;

// Red Rectangle 2 Variables
int r2Col;
int r2Row;
int r2OldCol;
int r2OldRow;
int r2CDel;
int r2RDel;
int r2Width;
int r2Height;

// Black Rectangle 1 Variables
int b1Col;
int b1Row;
int b1OldCol;
int b1OldRow;
int b1CDel;
int b1RDel;
int b1Width;
int b1Height;

// Black Rectangle 2 Variables
int b2Col;
int b2Row;
int b2OldCol;
int b2OldRow;
int b2CDel;
int b2RDel;
int b2Width;
int b2Height;

//Ship Variables
int shCol;
int shRow;
int shOldCol;
int shOldRow;
int shCDel;
int shRDel;
int shWidth;
int shHeight;

//End Game Variables 
int gameTimer;
int breakV;
int roundTime;

int main() {

	initialize();

	while(1) {
		update();
		if (breakV == 1) {
			break;
		}
		oldButtons = buttons;
		buttons = BUTTONS;
		waitForVBlank();
		draw();
	}
	if (gameTimer > roundTime) {
		drawWinScreen();
	} else {
		drawEndScreen();
	}
}

// Sets up the display and the game objects
void initialize() {

	REG_DISPCTL = MODE3 | BG2_ENABLE;

	oldButtons = 0;
	buttons = BUTTONS;

	// Initialize background
	bgColor = BLACK;
	fillScreen(bgColor);

	//Intialise parameters
	r1Row = 100;
	r1Col = 50;
	r1OldCol = r1Col;
	r1OldRow = r1Row;
	r1CDel = 1;
	r1RDel = 1;
	r1Width = 10;
	r1Height = 15;

	r2Row = 50;
	r2Col = 200;
	r2OldCol = r2Col;
	r2OldRow = r2Row;
	r2CDel = 1;
	r2RDel = 1;
	r2Width = 10;
	r2Height = 15;

	b1Row = 100;
	b1Col = 70;
	b1OldCol = b1Col;
	b1OldRow = b1Row;
	b1CDel = 1;
	b1RDel = 1;
	b1Width = 10;
	b1Height = 15;

	b2Row = 80;
	b2Col = 150;
	b2OldCol = b2Col;
	b2OldRow = b2Row;	
	b2CDel = 1;
	b2RDel = 1;
	b2Width = 10;
	b2Height = 15;

	shCol = 120;
	shRow = 80;
	
	gameTimer = 0;
	breakV = 0;
	roundTime = 3200;
}

// Performs all of the game's calculations
void update() {
	// Change the background color if Start is pressed
	if (BUTTON_PRESSED(BUTTON_A)) {
	 	if (bgColor == BLACK)
	 		bgColor = RED;
	 	else
	 		bgColor = BLACK;
	 	fillScreen(bgColor);
	}
	// Move the ship with the buttons
	if (BUTTON_HELD(BUTTON_LEFT)) {
		shCol--;
	}
	if (BUTTON_HELD(BUTTON_RIGHT)) {
		shCol++;
	}
	if (BUTTON_HELD(BUTTON_UP)) {
		shRow--;
	}
	if (BUTTON_HELD(BUTTON_DOWN)) {
		shRow++;
	}
	if (shRow <= 0) {
		shRow = (SCREENHEIGHT - 1);	
	} 	
	if (shRow + shHeight - 1 >= SCREENHEIGHT - 1) {
		shRow = 0;
	}
	
	if ((r1Col <= 0) || (r1Col + r1Width - 1 >= SCREENWIDTH - 1))  
		r1CDel *= -1;
	if ((r1Row <= 0) || (r1Row + r1Height - 1 >= SCREENHEIGHT - 1)) 
		r1RDel *= -1;
	
	if ((r2Col <= 0) || (r2Col + r2Width - 1 >= SCREENWIDTH - 1))  
		r2CDel *= -1;
	if (((r2Row <= 0) || (r2Row + r2Height - 1 >= SCREENHEIGHT - 1))) 
		r2RDel *= -1;
	
	if ((b1Col <= 0) || (b1Col + b1Width - 1 >= SCREENWIDTH - 1))  
		b1CDel *= -1;
	if ((b1Row <= 0) || (b1Row + b1Height - 1 >= SCREENHEIGHT - 1)) 
		b1RDel *= -1;
	
	if ((b2Col <= 0) || (b2Col + b2Width - 1 >= SCREENWIDTH - 1))  
		b2CDel *= -1;
	if ((b2Row <= 0) || (b2Row + b2Height - 1 >= SCREENHEIGHT - 1)) 
		b2RDel *= -1;
	
	//Ship Collisions (basically game ending condition)
	if (collision(r1Col,r1Row, r1Width, r1Height, shCol, shRow, shWidth, shHeight)) {
		breakV = 1;		
	}
	if (collision(r2Col, r2Row, r2Width, r2Height, shCol, shRow, shWidth, shHeight)) {
		breakV = 1;		
	}
	if (collision(b1Col, b1Row, b1Width, b1Height, shCol, shRow, shWidth, shHeight)) {
		breakV = 1;		
	}
	if (collision(b2Col, b2Row, b2Width, b2Height, shCol, shRow, shWidth, shHeight)) {
		breakV = 1;
	}

	// Update moving rectangles' position
	r1Col += r1CDel;
	r1Row += r1RDel;
	r2Col += r2CDel;
	r2Row += r2RDel;
	b1Col += b1CDel;
	b1Row += b1RDel;
	b2Col += b2CDel;
	b2Row += b2RDel;

	gameTimer += 1;
	if (gameTimer > roundTime) {
		breakV = 1;
	}
}

void draw() {
	//erases
	drawRect(r1OldCol, r1OldRow, r1Width, r1Height, bgColor);
	drawRect(r2OldCol, r2OldRow, r2Width, r2Height, bgColor);
	drawRect(b1OldCol, b1OldRow, b1Width, b1Height, bgColor);
	drawRect(b2OldCol, b2OldRow, b2Width, b2Height, bgColor);

	drawRect(shOldCol, shOldRow, 6, 5, bgColor);
  
	//draws
	drawRect(r1Col, r1Row, r1Width, r1Height, RED);
	drawRect(r2Col, r2Row, r2Width, r2Height, RED);
	drawRect(b1Col, b1Row, b1Width, b1Height, BLACK);
	drawRect(b2Col, b2Row, b2Width, b2Height, BLACK);
	drawShip(shCol, shRow);

	//updates
	r1OldCol = r1Col;
	r1OldRow = r1Row;
	r2OldCol = r2Col;
	r2OldRow = r2Row;
	b1OldCol = b1Col;
	b1OldRow = b1Row;
	b2OldCol = b2Col;
	b2OldRow = b2Row;

	shOldCol = shCol;
	shOldRow = shRow;
}